public class PeakFinding {
    
    /*
     * Additional rules not mentioned in class:
     * If the heights are monotonic, then return
     * the index of the highest element. If the
     * heights remain constant, return any element.
     */
    
    //tester method
    public static double[] generatePeak(int index, int length) {
        assert index < length;
        double[] ret = new double[length];
        for (int i = 1; i<=index; i++) {
            ret[i] = (ret[i-1] + 1) * 1.5;
        }
        for (int i = index + 1; i<length; i++) {
            ret[i] = ret[i-1] * 0.9;
        }
        return ret;
    }
    
    private static boolean leftSlope(double[] heights, int i) {
        if (i == heights.length - 1) {
            return heights[i-1] < heights[i];
        } else {
            return heights[i] > heights[i+1];
        }
    }
    
    private static boolean isPeak(double[] heights, int i) {
        return 
            i == 0 || i == heights.length - 1 ||
            heights[i] > heights[i-1] &&
            heights[i] > heights[i+1];
    }
    
    /* 
     * Compare this code to first bad version.
     * How are the indices different? How/why is
     * this mid calculator better than simply taking the average?
     * Compare with the generic binary search code on the slides,
     * as well.
     */
    
    public static int findPeak(double[] heights) {
        int lo = 0;
        int hi = heights.length - 1;
        while (lo < hi) {
            int mid = lo + (hi - lo)/2;
            if (isPeak(heights, mid)) {
                return mid;
            } else if (leftSlope(heights, mid)) {
                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        }
        return hi;
    }
    
    
    public static void main(String[] args) {
        int peak = 68;
        int length = 180;
        System.out.println(findPeak(new double[] {0,0,0,0,0,0}));
        System.out.println(findPeak(generatePeak(peak, length)));
    }
   
}
